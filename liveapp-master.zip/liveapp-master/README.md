# Live App [![Open in MATLAB Online](https://www.mathworks.com/images/responsive/global/open-in-matlab-online.svg)](https://matlab.mathworks.com/open/github/v1?repo=slevin48/liveapp&file=SolarPanelEstimator.mlx)

![liveapp](https://www.mathworks.com/help/examples/matlab/win64/xxSolarPanelOutputEstimator.png)

Resources:
* [Create an Interactive Form Using the Live Editor](https://www.mathworks.com/help/matlab/matlab_prog/live-editor-to-create-interactive-form.html)
* [How to Turn Your Script into a Simple App](https://github.com/mathworks/how-to-turn-your-script-into-a-simple-app)